package com.example.examenfinal.models;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ItemList {
    private ArrayList<ItemListItem> results;

    public ArrayList<ItemListItem> getResults() { return results;}
}
