package com.example.examenfinal.models;

public class ItemListItem {

    private String name;

    private Item.ItemSprites sprites;
    public String getName() {
        return name;
    }

    public Item.ItemSprites getSprites() {
        return sprites;
    }
}
