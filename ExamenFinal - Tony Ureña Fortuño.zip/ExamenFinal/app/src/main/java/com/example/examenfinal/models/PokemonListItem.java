package com.example.examenfinal.models;

public class PokemonListItem {
    String name;

    public String getName() {
        return name;
    }
}
